model Messketteadvanced
  BearingLibrary.VirtualBench_layout_v1 virtualBench_layout_v1(fs_command = 17)  annotation(
    Placement(transformation(origin = {-141, -7}, extent = {{-15, -15}, {15, 15}})));
  IEPE_WithChargeAmplifier_Block iEPE_WithChargeAmplifier_Block annotation(
    Placement(transformation(origin = {-61, -5}, extent = {{-25, -25}, {25, 25}})));
  Modelica.Blocks.Continuous.LowpassButterworth lowpassButterworth1(f = 500, n = 4) annotation(
    Placement(transformation(origin = {24, 0}, extent = {{-22, -22}, {22, 22}})));
  Modelica.Blocks.Discrete.Sampler sampler1(samplePeriod = 1/5120) annotation(
    Placement(transformation(origin = {89, 3}, extent = {{-13, -13}, {13, 13}})));
  Modelica.Blocks.Discrete.ZeroOrderHold zeroOrderHold1(samplePeriod = 1/5120) annotation(
    Placement(transformation(origin = {172, 4}, extent = {{-16, -16}, {16, 16}})));
  ADU adu1(Umax = 17, Umin = 7, steps = 4096) annotation(
    Placement(transformation(origin = {224, 4}, extent = {{-14, -14}, {14, 14}})));
equation
  connect(virtualBench_layout_v1.acc_x, iEPE_WithChargeAmplifier_Block.acc_x) annotation(
    Line(points = {{-141, 5}, {-116.5, 5}, {-116.5, -5}, {-86, -5}}, color = {0, 0, 127}));
  connect(iEPE_WithChargeAmplifier_Block.v_out, lowpassButterworth1.u) annotation(
    Line(points = {{-36, -5}, {-8, -5}, {-8, 0}, {-2, 0}}, color = {0, 0, 127}));
  connect(lowpassButterworth1.y, sampler1.u) annotation(
    Line(points = {{48, 0}, {73, 0}, {73, 3}}, color = {0, 0, 127}));
  connect(sampler1.y, zeroOrderHold1.u) annotation(
    Line(points = {{103, 3}, {103, 3.5}, {139, 3.5}, {139, 3.75}, {153, 3.75}, {153, 4}}, color = {0, 0, 127}));
  connect(zeroOrderHold1.y, adu1.real_i) annotation(
    Line(points = {{190, 4}, {209, 4}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "4.0.0")),
  experiment(StartTime = 0, StopTime = 10, Tolerance = 1e-06, Interval = 0.001),
  Diagram(graphics = {Text(origin = {-194, 49}, extent = {{-62, 9}, {62, -9}}, textString = "Virtualbench gibt hier eine Beschleunigung raus (acc_x in m/s^2)."), Text(origin = {25, 81}, extent = {{-211, 45}, {211, -45}}, textString = "Der IEPE Beschleunigungssensor nimmt die Beschleunigung und wandelt diese in eine Ladung um. Mithilfe der Sensitivität wird die der Ladungsverstärker abstrahiert (um das Modell Simpel zu halten, der Ausgang gibt dann eine Spannung)."), Line(origin = {-60, 57}, points = {{0, 19}, {0, -19}, {0, -19}}), Line(origin = {-141.114, 37.1136}, points = {{-26.8864, 6.88645}, {-12.8864, -1.11355}, {-12.8864, -1.11355}}), Text(origin = {-14, -58}, extent = {{-44, 16}, {44, -16}}, textString = "Die Dimensionierung des FIlters basiert auf Grundlage der Abtastfrequenz des Samplers und des ADUs. Außerdem benötigt man die Grenzfrequenz (gegeben durch den IEPE sensor mit Bandpass verhalten bis zu 10kHz). Diese10 kHz sind unsere Grundlage für die Abtastung. Wir müssen laut dem Abtasttheorem von Shanon eine Abtastfrequenz von mind. 2xGrenzfrequenz einhalten. Deshalb Tasten wir mit 30kHz ab (3.33e-5 von sampler und zeroOrderHold). Außerdem muss die Ordnung des Filters bestimmt werden. Diese wird mithilfe von formeln für Anti Aliasing bestimmt (-20 log ..../log...). Raus kommt am Ende 143,115 dB, was 7,11 dB pro decade entspricht. Das heisst wir brauchen mindestens einen Filter der 8ten Ordnung, um den Filter korrekt zu dimensionieren."), Text(origin = {-55, -85}, extent = {{-73, 9}, {73, -9}}, textString = "Darauf folgt die restiliche Messkette mit sampler, ZerooderHold und ADU. Der ADU gibt uns am Ende entweder spannung, oder auch codes (was auch immer gewünscht ist). Der ADU muss auf jeden fall besser dimensioniert werden denke ich mal.")}));
end Messketteadvanced;
